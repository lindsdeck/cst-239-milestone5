package Products;

public interface Comparable
{
	public boolean compareTo(String productName);
}
