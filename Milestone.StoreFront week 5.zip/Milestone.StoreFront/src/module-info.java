/**
 * 
 */
/**
 * 
 */
module Milestone.StoreFront {
	
	requires com.fasterxml.jackson.databind;
	requires com.fasterxml.jackson.annotation;
	opens Products to com.fasterxml.jackson.databind;
}