package InventoryManager;

import java.util.ArrayList;
import java.util.List;
import Products.Product;
import java.util.Collections;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Stack;
import Products.Product;

public class InventoryManager 
{
	private Stack<Product> products;
	/**
	 * 0
	 */
	public InventoryManager()
	{
		products = new Stack<>();
		
	}
	/**
	 * Add a new product to the product stack
	 */
	public void addProduct(Product product)
	{
		products.push(product);
	}
	/**
	 * Remove a product from the product stack
	 */
	public void removeProduct(Product product)
	{
		//products.pop(product);
		int location = products.indexOf(product);
		products.remove(location);
	}
	/**
	 * get the product list
	 * @return
	 */
	public Stack<Product> getProducts()
	{
		return products;
	}
	/**
	 * 
	 */
	public void DisplayInventory()
	{
		if (products.isEmpty())
		{
			System.out.println("There is nothing in the shop today! Come back later!");
		}
		else
		{	
			//Print the list in alphabetical order based on the name of the product.
			List<Product> productList = new ArrayList<>(products);
			Collections.sort(productList, (p1, p2) -> p1.getName().compareToIgnoreCase(p2.getName()));
			for (Product product : productList)
			{
			System.out.println(product);
			}
			System.out.println();
		}
	}
	/**
	 * 
	 * @param product
	 */
	public void checkProductExists(Product product)
	{
		if(products.contains(product))
		{
			product.updateQuantity(product.getQuantity() +1);
		}
		else
		{
			products.add(product);
		}
	}

	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
	

	}
	/**
	 * 
	 * @param filename
	 */
	/**
	public void LoadFromFile(String filename)
	{
		ObjectMapper objectMapper = new ObjectMapper();
		
	    objectMapper.activateDefaultTyping(
	        objectMapper.getPolymorphicTypeValidator(),
	        ObjectMapper.DefaultTyping.NON_FINAL,
	        JsonTypeInfo.As.PROPERTY);
	    
	    try 
	    {
	        products = objectMapper.readValue(new File(filename),
	            objectMapper.getTypeFactory().constructCollectionType(List.class, Product.class));
	    } catch (IOException e) 
	    {
	        System.out.println("There has been an error reading from the file. The error is: " + e.getMessage());
	    }
	}
	*/
	/**
	 * 
	 * @param filename
	 */
	/**public void SaveToFile(String filename)
	{
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.activateDefaultTyping(
		        objectMapper.getPolymorphicTypeValidator(),
		        ObjectMapper.DefaultTyping.NON_FINAL,
		        JsonTypeInfo.As.PROPERTY);

		try
		{
			objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File(filename), products);
			//objectMapper.writeValue(new File(filename), products);
		}
		catch(IOException e)
		{
			System.out.println("There has been an error writing to the file.  The error is: " + e.getMessage());
		}
	}
	*/

}
