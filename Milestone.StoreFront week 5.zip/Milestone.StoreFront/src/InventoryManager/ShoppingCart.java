package InventoryManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import Products.Product;
import java.util.Stack;
import Products.Product;


public class ShoppingCart 
{
	private Stack<Product> cart;
	/**
	 * 
	 */
	public ShoppingCart()
	{
		cart = new Stack<>();
	}
	public void DisplayCart()
	{
		if (getCartInventory().isEmpty())
		{
			System.out.println("There is nothing in your shopping cart.  Please add any items you would like to purchase!" + "\n");
		}
		else
		{
			//Print the list in alphabetical order based on the name of the product.
			List<Product> productList = new ArrayList<>(cart);
			Collections.sort(productList, (p1, p2) -> p1.getName().compareToIgnoreCase(p2.getName()));
			for (Product product : productList)
			{
			System.out.println(product);
			}
			System.out.println();
		}
	}
	/**
	 * 
	 * @param product
	 */
	public void addProduct(Product product)
	{
		
		cart.push(product);
	}
	/**
	 * 
	 * @param product
	 */
	public void removeProduct(Product product)
	{
		//products.pop(product);
		int location = cart.indexOf(product);
		cart.remove(location);
	}
	/**
	 * 
	 * @return
	 */
	public Stack<Product> getCartInventory()
	{
		return cart;
	}
	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
		

	}

}
